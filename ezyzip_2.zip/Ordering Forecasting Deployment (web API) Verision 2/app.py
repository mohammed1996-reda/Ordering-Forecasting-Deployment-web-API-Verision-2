#import libraries
##################################################
##################################################
##################################################
############# Created by Dr. Mohamed R. Shoaib
############# Created at: 25/05/2022
############# Shgardi Company
##################################################
##################################################
##################################################
import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from gevent.pywsgi import WSGIServer
import pandas as pd
#Initialize the flask App
from flask import Flask, request, render_template, redirect, url_for, flash, send_file, make_response
import pandas as pd
import io
app = Flask(__name__)
from sklearn.preprocessing import OrdinalEncoder
from werkzeug.utils import secure_filename
ord_enc = OrdinalEncoder()
#default page of our web-app
@app.route('/')
def home():
    return render_template('index.html')
#####################################################

model = pickle.load(open('xgb.sav', 'rb'))
#To use the predict button in our web-app
@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''

    int_features = [float(x) for x in request.form.values()]
    final_features = np.array(int_features)
    df = pd.DataFrame(final_features)
    prediction = model.predict(df.T)
    output = prediction.round()

    return render_template('index.html', prediction_text='the number of orders is :{}'.format(output))


if __name__ == "__main__":
    app.run(debug=True)
